<?php include('../config/constants.php'); ?>

<?php 

    $id = $_GET['id'];
    
    $sqlDeleteAdminQuery = "DELETE FROM tbl_admin WHERE id = $id";
    $sqlDeleteAdminQueryExecuted = mysqli_query($databaseConnection, $sqlDeleteAdminQuery);
    
    if($sqlDeleteAdminQueryExecuted == TRUE) {
        
        // echo "Admin Deleted Successfully";
        $_SESSION['delete'] = "Admin Deleted Successfully";
        header("location:" . SITE_URL . 'admin/manage-admin.php');

    } else {
        
        // echo "Failed to Delete Admin. Try Again!";
        $_SESSION['delete'] = "Failed to Delete Admin. Try Again!";
        header("location:" . SITE_URL . 'admin/manage-admin.php');

    }

?>