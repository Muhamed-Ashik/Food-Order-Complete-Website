<?php 
    include('../config/constants.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Foor Order - Manage Admin</title>

    <link rel="stylesheet" href="../css/admin.css">

</head>
<body>
    

<!-- Include the Menu File -->
<?php 
    include('partials/menu.inc.php');
?>

    <!-- Start of the Main Content -->
    <div class="main-content">
        <div class="wrapper">
            <h1 class="main-heading">Manage Admin</h1>

            <?php 
                if(isset($_SESSION['add'])){
                    ?>
                        <h2 style="color: green; padding-bottom: 3%;">
                            <?php echo $_SESSION['add']; ?>
                        </h2>
                    <?php
                    unset($_SESSION['add']);
                }

                if(isset($_SESSION['delete'])) {
                    ?>
                        <h2 style="color: green; padding-bottom: 3%;"> 
                            <?php echo $_SESSION['delete']; ?> 
                            
                        </h2> 
                    <?php
                    unset($_SESSION['delete']);
                }

                if(isset($_SESSION['update'])) {
                    ?>
                        <h2 style="color: green; padding-bottom: 3%;">
                             <?php echo $_SESSION['update']; ?> 
                        </h2>
                        
                    <?php

                    unset($_SESSION['update']);
                } 

                if(isset($_SESSION['user-not-found'])) {
                    ?>  

                        <h2 style="color: red; padding-bottom: 3%;">
                             <?php echo $_SESSION['user-not-found']; ?> 
                        </h2>

                    <?php 

                    unset($_SESSION['user-not-found']);
                }

                 
            
                if(isset($_SESSION['password-check'])) {
                    ?>

                        <h2 style="color: red; padding-bottom: 3%;">
                            <?php echo $_SESSION['password-check'] ?>
                        </h2>

                    <?php

                    unset($_SESSION['password-check']);

                 }  
                 
                 
                 if(isset($_SESSION['password-changed'])) {
                     ?>

                        <h2 style="padding-bottom: 3%; ">
                            <?php echo $_SESSION['password-changed']; ?>
                        </h2>

                     <?php

                     unset($_SESSION['password-changed']);
                 }

            
            
            ?>

            <!-- <br> <br> -->

            <!-- Button for Add Admin -->
            <a href="add-admin.php" class="btn-add">Add Admin</a>

            <table class="admin-view-table" border="1">
                <tr>
                    <th>S.N</th>
                    <th>Full Name</th>
                    <th>Username</th>
                    <th>Actions</th>
                </tr>

                <?php 

                    $sqlAdminFetchQuery = "SELECT * FROM tbl_admin";

                    $sqlAdminFetchQueryExecuted = mysqli_query($databaseConnection, $sqlAdminFetchQuery);

                    if($sqlAdminFetchQueryExecuted == TRUE) {
                        
                        $count = mysqli_num_rows($sqlAdminFetchQueryExecuted);

                        if($count > 0) {
                            
                            $serial_number_count = 1;

                            while($fetchRows = mysqli_fetch_assoc($sqlAdminFetchQueryExecuted)) {

                                $id = $fetchRows['id'];
                                $full_name = $fetchRows['full_name'];
                                $username = $fetchRows['username'];

                                ?>

                                <tr>
                                        <td><?php echo $serial_number_count++; ?></td>
                                        <td><?php echo $full_name; ?></td>
                                        <td><?php echo $username; ?></td>
                                    <td>
                                        <a href="<?php echo SITE_URL ?>admin/update-password.php?id=<?php echo $id; ?>" class="btn-update">Change Password</a>
                                        <a href="<?php echo SITE_URL ?>admin/update-admin.php?id=<?php echo $id; ?>" class="btn-update">Update Admin</a>
                                        <a href="<?php echo SITE_URL ?>admin/delete-admin.php?id=<?php echo $id; ?>" class="btn-delete">Delete Admin</a>
                                    </td>
                                </tr>

                                <?php

                            }

                        } 

                    } 

                ?>
                 
            </table>

        </div><!--End of the Wrapper Div-->
    </div><!--End of the Main Content Div-->



<!-- Include the Foote File -->
<?php 
    include('partials/footer.inc.php');
?>

</body>
</html>



