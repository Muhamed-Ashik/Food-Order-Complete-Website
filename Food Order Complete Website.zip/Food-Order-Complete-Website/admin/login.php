<?php include('../config/constants.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Order - Login Page</title>

    <link rel="stylesheet" href="../css/admin.css"/>

</head>
<body>

    <div class="login">
        <h1 class="login-heading text-align">Login</h1>

        <?php 
        
            if(isset($_SESSION['field-empty'])) {
                ?>

                    <h3>
                        <?php echo $_SESSION['field-empty']; ?>
                    </h3>

                <?php

                unset($_SESSION['field-empty']);

            }

            if(isset($_SESSION['login-password-check'])) {
                ?>
                    <h3>
                        <?php echo $_SESSION['login-password-check']; ?>
                    </h3>
                <?php

                unset($_SESSION['login-password-check']);
            }

            if(isset($_SESSION['logedUser'])) {
                ?> 
                    <h3 class="error">
                        <?php echo $_SESSION['logedUser']; ?>
                    </h3>
                 <?php 
            }

            unset($_SESSION['logedUser']);

        ?>
        
        <form action="" method="POST" class="text-align">
            <label for="">Username: </label>
            <input type="text" name="username"/> <br> <br> <br>

            <label for="">Password: </label>
            <input type="password" name="password"/> <br> <br> <br>

            <input type="submit" name="submit" value="Login" class="btn-add"/>
        </form>

    </div>
    
    <?php include('partials/footer.inc.php'); ?>

</body>
</html>

<?php 

    if(isset($_POST['submit'])) {

        if(empty($_POST['username']) && empty($_POST['password'])) {

           $_SESSION['field-empty'] = "<div class='error text-align'>All Fields Must be Fill</div>";
           header('location:' . SITE_URL . 'admin/login.php');

        } else {

            $username = $_POST['username'];
            $password = md5($_POST['password']);

            $sqlFetchAdminQuery = "SELECT * FROM tbl_admin WHERE username = '$username' && password = '$password'";
            $sqlFetchAdminQueryExecuted = mysqli_query($databaseConnection, $sqlFetchAdminQuery);

            if($sqlFetchAdminQueryExecuted == TRUE) {

                $sqlFetchCount = mysqli_num_rows($sqlFetchAdminQueryExecuted);

                if($sqlFetchCount == 1) {
                    // Loging
                    
                    $_SESSION['login-password-check'] = "<div> <span class='success'> Login Successful </span> </div>";
                    header('location:' . SITE_URL . 'admin/');

                    $_SESSION['logedUser'] = "<div class='success'>$username</div>"; // once the record found take tha username

                } else {
                    // Failed
                    $_SESSION['login-password-check'] = "<div class='error text-align'>Username or Password Wrong. Try Again!</div>";
                    header('location:' . SITE_URL . 'admin/login.php');
                }

            }

        }

    }
    
?>