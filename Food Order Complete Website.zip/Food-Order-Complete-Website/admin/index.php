<?php 
    include('../config/constants.php');
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Order - Dashboard</title>

    <link rel="stylesheet" href="../css/admin.css">

</head>
<body>

<!-- Including the Menu File -->
<?php 
    include('partials/menu.inc.php');
?>

    <!-- Start of the Main Content -->
    <div class="main-content">
        <div class="wrapper">
            <h1 class="main-heading">Dashboard</h1>

            <?php 

                if(isset($_SESSION['login-password-check'])) {
                    ?>
                        <h2>
                            <?php 
                                echo $_SESSION['login-password-check'] ;
                                ?>
                        </h2>

                        
                        <?php
                }
                
                unset($_SESSION['login-password-check'])
                
                ?>

            <h3> 
                <?php echo $_SESSION['logedUser']; ?>
            </h3>

            <div class="dashboard-box col-4 text-align">
                <h1>5</h1>
                <br>
                Categories
            </div><!--END OF THE Dashboard Box Div-->

            <div class="dashboard-box col-4 text-align">
                <h1>5</h1>
                <br>
                Categories
            </div>

            <div class="dashboard-box col-4 text-align">
                <h1>5</h1>
                <br>
                Categories
            </div>

            <div class="dashboard-box col-4 text-align">
                <h1>5</h1>
                <br>
                Categories
            </div>

            <div class="clear-fix"></div>

        </div>
    </div>
    <!-- End of the Main Content -->

  <!-- Include Footer File -->
  <?php 
    include('partials/footer.inc.php');
  ?>


</body>
</html>