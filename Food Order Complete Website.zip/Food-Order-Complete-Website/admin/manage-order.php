<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Order - Manage Order</title>

    <link rel="stylesheet" href="../css/admin.css">

</head>
<body>

<?php 
    include('partials/menu.inc.php');
?>

    <div class="main-content">
        <div class="wrapper">
            <h1>Manage Order</h1>        

            <table class="admin-view-table">
                <tr>
                    <th>S.N</th>
                    <th>Full Name</th>
                    <th>Username</th>
                    <th>Actions</th>
                </tr>

                <tr>
                    <td>001</td>
                    <td>Mohamed Ashik</td>
                    <td>Ashik</td>
                    <td>
                      <a href="#" class="btn-update">Update Order</a>
                      <a href="#" class="btn-delete">Delete Order</a>
                    </td>
                </tr>

                 <tr>
                    <td>002</td>
                    <td>Mohamed Ashik</td>
                    <td>Ashik</td>
                    <td>
                        <a href="#" class="btn-update">Update Order</a>
                        <a href="#" class="btn-delete">Delete Order</a>
                    </td>
                </tr>

                 <tr>
                    <td>003</td>
                    <td>Mohamed Ashik</td>
                    <td>Ashik</td>
                    <td>
                        <a href="#" class="btn-update">Update Order</a>
                        <a href="#" class="btn-delete">Delete Order</a>
                    </td>
                </tr>
            </table>


        </div><!--End of the Wrapper Div-->
    </div><!--End of the Main Content Div-->




<?php 
    include('partials/footer.inc.php');
?>

    
</body>
</html>