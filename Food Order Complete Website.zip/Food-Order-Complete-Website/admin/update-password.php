<?php include('../config/constants.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Order - Update Password</title>

    <link rel="stylesheet" href="../css/admin.css">

</head>
<body>

<?php include('partials/menu.inc.php'); ?>

<!-- Start of the Main Content -->

    <div class="main-content">
        <div class="wrapper">
            <h1 class="main-heading">Change Password</h1>

            <form action="" method="POST">
                <table class="table-30">
                    <tr>
                        <td>Current Password</td>
                        <td>
                            <input type="password" name="current-password" placeholder="Enter the Current Password"/>
                        </td>
                    </tr>

                    <tr>
                        <td>New Password: </td>
                        <td>
                            <input type="password" name="new-password" placeholder="Enter the New Password" />
                        </td>
                    </tr>

                    <tr>
                        <td>Confirm Password: </td>
                        <td>
                            <input type="password" name="confirm-password" placeholder="Re-type Confirm Password" />
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <input type="submit" name="submit" value="Change Password" class="btn-update"/>
                        </td>
                    </tr>

                </table>
            </form> 

        </div>
    </div>

<!-- End of the Main Content -->

<?php include('partials/footer.inc.php'); ?>
    
</body>
</html>


<?php 

if(isset($_POST['submit'])) {

    $id = $_GET['id'];

    $current_password = md5($_POST['current-password']);
    $new_password = md5($_POST['new-password']);
    $confirm_password = md5($_POST['confirm-password']);

    $sqlFetchAdminQuery = "SELECT * FROM tbl_admin WHERE id=$id AND password='$current_password'";
    $sqlFetchAdminQueryExecuted = mysqli_query($databaseConnection, $sqlFetchAdminQuery);

    if($sqlFetchAdminQueryExecuted == TRUE) {

        $sqlFetchCount = mysqli_num_rows($sqlFetchAdminQueryExecuted);
        
        if($sqlFetchCount == 1) {
            // Record Available
            // echo "Record Avaliable";

            if($new_password == $confirm_password) {

                $sqlAdminPasswordUpdateQuery = "UPDATE tbl_admin SET
                    password = '$confirm_password'
                    WHERE id = $id;
                ";

                $sqlAdminPasswordUpdateQueryExecuted = mysqli_query($databaseConnection, $sqlAdminPasswordUpdateQuery);

                if($sqlAdminPasswordUpdateQueryExecuted == TRUE) {

                    $_SESSION['password-changed'] = "Password Changed Successfully";
                    header('location:' . SITE_URL . 'admin/manage-admin.php');

                } else {

                    $_SESSION['password-changed'] = "Password Not Changed. Try Again!";
                    header('location:' . SITE_URL . 'admin/manage-admin.php');

                }

            } else{

                $_SESSION['password-check'] = "Password Not Matched. Try Again!";
                header('location:' . SITE_URL . 'admin/manage-admin.php');

            }

        } else {
            // Record not available
            // echo "Record Not Found";
            $_SESSION['user-not-found'] = "User Not Found. Try Again!";
            header('location:' . SITE_URL . 'admin/manage-admin.php');
        }

    }

} // End of the Submit button if condition

?>