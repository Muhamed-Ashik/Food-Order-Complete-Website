  <!-- Start of the Footer -->
    <div class="footer">
        <div class="wrapper">
            <p class="text-align">2022 All Rights Reserved, Some Resturant Developed By - <a href="#">Mohamed Ashik<a/></p>
        </div>
    </div>
    <!-- End of the Footer -->
