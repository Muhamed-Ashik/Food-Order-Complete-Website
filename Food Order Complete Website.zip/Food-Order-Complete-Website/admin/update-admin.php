<?php include('../config/constants.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Order - Update Admin</title>

    <link rel="stylesheet" href="../css/admin.css">

</head>
<body>

<!-- Start of the Menu -->

<?php include('partials/menu.inc.php'); ?>

<!-- End of the Menu -->

<!-- Start of the Main Content -->

<div class="main-content">
    <div class="wrapper">
        <h1 class="main-heading">Update Admin</h1>

        <?php 
        
        $id = $_GET['id'];

        $sqlAdminFetchQuery = "SELECT * FROM tbl_admin WHERE id = $id";
        $sqlAdminFetchQueryExecuted = mysqli_query($databaseConnection, $sqlAdminFetchQuery);
        if($sqlAdminFetchQueryExecuted == TRUE) {
            
            $sqlCount = mysqli_num_rows($sqlAdminFetchQueryExecuted);

            if($sqlCount == 1) {

                $sqlRow = mysqli_fetch_assoc($sqlAdminFetchQueryExecuted);

                // echo "Record Available";

                $full_name  = $sqlRow['full_name'];
                $username = $sqlRow['username'];

            } else {
                header("location:". SITE_URL . 'admin/manage-admin.php');
            }

        }
        ?>

        <form action="" method="POST">
            <table class="table-30"> 

                <input type="hidden" name="id" value="<?php echo $id; ?>">

                <tr>
                <td>Full Name: </td>
                <td>
                    <input type="text" name="full_name" value="<?php echo $full_name; ?>">
                </td>
            </tr>

            <tr>
                <td>Username: </td>
                <td>
                    <input type="text" name="username" value="<?php echo $username; ?>">
                </td>
            </tr>

            <tr>
                <td>
                    <input type="submit" name="submit" value="Update Admin" class="btn-update">
                </td>
            </tr>

            </table>
        </form>

    </div>
</div>

<!-- End of the Main Content -->

<!-- Start of the Footer -->

<?php include('partials/footer.inc.php'); ?>

<!-- End of the Footer -->
</body>
</html>


<?php 

    if(isset($_POST['submit'])) {
        $id = $_POST['id'];
        $full_name = $_POST['full_name'];
        $username = $_POST['username'];

        $sqlUpdateAdminQuery = "UPDATE tbl_admin SET 
            full_name = '$full_name',
            username = '$username'
            WHERE id = $id;
        ";

        $sqlUpdateAdminQueryExecuted = mysqli_query($databaseConnection, $sqlUpdateAdminQuery);

        if($sqlUpdateAdminQueryExecuted == TRUE) {
            
            $_SESSION['update'] = "Admin Updated Successfully";
            header('location:' . SITE_URL . 'admin/manage-admin.php');

        } else {

            $_SESSION['update'] = "Failed to Update Admin. Try Again!";
            header("location:" . SITE_URL . 'admin/manage-admin.php');

        }

        
    }

?>