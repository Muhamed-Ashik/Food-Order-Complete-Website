<?php include('config/constants.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <!-- Important to make website responsive -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurant Website - Foods</title>

    <!-- Link our CSS file -->
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    
    <!-- START OF THE NAVBAR SECTION -->
        <?php 

            include('front-partials/menu.inc.php');

        ?>
    <!-- END OF THE NAVBAR SECTION -->

    <!-- fOOD sEARCH Section Starts Here -->
    <section class="food-search text-center">
        <div class="container">
            
            <form action="<?php echo SITE_URL ?>food-search.php" method="POST">
                <input type="search" name="search" placeholder="Search for Food.." required>
                <input type="submit" name="submit" value="Search" class="btn btn-primary">
            </form>

        </div>
    </section>
    <!-- fOOD sEARCH Section Ends Here -->



    <!-- fOOD MEnu Section Starts Here -->
    <section class="food-menu">
        <div class="container">
            <h2 class="text-center">Food Menu</h2>

            <!-- FETCH THE FOOD -->

                <?php 
                    // query fetch the food which are only active YES
                    $sqlFetchFood = "SELECT * FROM tbl_food WHERE active = 'Yes'";

                    // execute the query
                    $sqlFetchFoodExecuted = mysqli_query($databaseConnection, $sqlFetchFood);

                    // get the count of all food
                    $sqlRowsCount = mysqli_num_rows($sqlFetchFoodExecuted);

                    // check wether the count is available or not
                    if($sqlRowsCount > 0) {

                        
                         // Food Availalbe, then fetch it using while loop
                        while($sqlRows = mysqli_fetch_assoc($sqlFetchFoodExecuted)) {

                            // store the data in vaiables
                            $id = $sqlRows['id'];
                            $title = $sqlRows['title'];
                            $price = $sqlRows['price'];
                            $description = $sqlRows['description'];
                            $image_name = $sqlRows['image_name'];

                            ?>

                            <div class="food-menu-box">
                                <div class="food-menu-img">

                                    <?php

                                        // check whether image is available or not
                                        if($image_name == "") {
                                            // Image Not Available, then display the message
                                            echo "<h5 class='error'>Image Not Available</h5>";
                                        } else {
                                            // Image Available, then display image
                                            ?>
                                                <img src="<?php echo SITE_URL ?>images/food/<?php echo $image_name; ?>" alt="Chicke Hawain Pizza" class="img-responsive img-curve">
                                            <?php
                                        }

                                    ?>

                                </div>

                                <div class="food-menu-desc">
                                    <h4><?php echo $title; ?></h4>
                                    <p class="food-price">Rs: <?php echo $price; ?></p>
                                    <p class="food-detail">
                                        <?php echo $description; ?>
                                    </p>
                                    <br>

                                    <a href="#" class="btn btn-primary">Order Now</a>
                                </div>
                            </div>

                            <?php

                        }


                    } else {

                        // Food not available, display the message
                        echo "<h1 class='error'>Food Not Available</h1>";

                    }
                ?>

            <div class="clearfix"></div>

            

        </div>

    </section>
    <!-- fOOD Menu Section Ends Here -->

    <!-- START OF THE FOOTER SECTION -->
        <?php 

            include('front-partials/footer.inc.php');

        ?>
    <!-- END OF THE FOOTER SECTION -->

</body>
</html>