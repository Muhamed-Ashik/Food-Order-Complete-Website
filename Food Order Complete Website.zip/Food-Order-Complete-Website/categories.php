<?php include('config/constants.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <!-- Important to make website responsive -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurant Website - Categories</title>

    <!-- Link our CSS file -->
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    
    <!-- START OF THE NAVBAR SECTION -->
        <?php 
            include('front-partials/menu.inc.php');
        ?>
    <!-- END OF THE NAVBAR SECTION -->

    <!-- CAtegories Section Starts Here -->
    <section class="categories">
        <div class="container">
            <h2 class="text-center">Explore Foods</h2>

            <?php

                $sqlFetchCategory = "SELECT * FROM tbl_category WHERE active = 'Yes' "; // create a query to fetch categories
                $sqlFetchCategoryExecuted = mysqli_query($databaseConnection, $sqlFetchCategory);// execute the query
                $sqlRowCount = mysqli_num_rows($sqlFetchCategoryExecuted); // get the count of all the data 

                // check whether the count is availalbe or not
                if($sqlRowCount > 0) {

                    // Data Available
                    // echo "Data found";

                    // get all the data using the while loop
                    while($sqlRows = mysqli_fetch_assoc($sqlFetchCategoryExecuted)) {

                        // get the data and store in the variable
                        $id = $sqlRows['id'];
                        $title = $sqlRows['title'];
                        $image_name = $sqlRows['image_name'];

                    ?>

                        <a href="category-foods.html">
                            <div class="box-3 float-container">

                                <?php 
                                
                                    if($image_name == "") {

                                        // No Image Found, then print the message
                                        echo "<h4 class='error'>No Image Added</h4>";

                                    } else {

                                        // Image Found ,then display the image
                                        ?>
                                             <img src="<?php echo SITE_URL ?>images/category/<?php echo $image_name; ?>" class="img-responsive img-curve"> 
                                        <?php

                                    } // END OF THE IMAGE AVAILABLE CHECK IF AND ELSE
                                
                                ?>
                                 
                                 <h3 class="float-text text-white"><?php echo $title; ?></h3>

                            </div>
                        </a>

                    <?php

                    } // END OF THE WHILE LOOP

                } else {

                    // Data not available
                    echo "<h4 class='error'>No Category Found</h4>";

                }


             ?>

            <div class="clearfix"></div>
        </div>
    </section>
    <!-- Categories Section Ends Here -->

    <!-- START OF THE FOOTER SECTION -->
        <?php 

            include('front-partials/footer.inc.php');

        ?>
    <!-- END OF THE FOOTER SECTION -->

</body>
</html>