-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 18, 2022 at 05:03 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `food-order`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(10) UNSIGNED NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `full_name`, `username`, `password`) VALUES
(4, 'Mohamed Ashik', 'Ashik', 'bc2ab28e4cda984ca76646874371e864'),
(5, 'Rizmy Mohamed', 'Rizmy', '049c6b9a7f1be6f4cc83124a95bc7ee7'),
(6, 'Mohamed Humaid', 'Humaid', 'e31e58b1958b7074237c6726cb5ff976'),
(7, 'Mohamed Sharaf', 'Sharaf', 'e2a8e02c5f6627d19a3d925efc759d0f'),
(8, 'Puwanegar ', 'Puwan', 'fce4e5cb1047aefad201a7d9da5bb10b'),
(11, 'Mohamed Akil', 'Akil', 'e6baeffb6b31b761a785fe371914817d'),
(12, 'Mohamed luqman', 'luqman', '4781c13b4bf9b7288a343fd274ff0310'),
(14, 'Arshard Ahamed', 'Arshard', '99d1568c2fe6dabf16c2f220d83f1b0e'),
(15, 'Mohamed Zafir', 'Zafir', 'e492d0f7fc69ec2ccb54130b99b310a5'),
(16, 'John Smith', 'John', '61409aa1fd47d4a5332de23cbf59a36f'),
(17, 'Administrator', 'Admin', 'e3afed0047b08059d0fada10f400c1e5'),
(18, 'Admin', 'Admin', '3124e63231a4594958d87771b4aaf064');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `featured` varchar(10) NOT NULL,
  `active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `title`, `image_name`, `featured`, `active`) VALUES
(12, 'Category 1 Copy', 'Food_Category_802.jfif', 'Yes', 'Yes'),
(13, 'Category 2', 'Food_Category_796.jfif', 'Yes', 'Yes'),
(14, 'Category 3', 'Food_Category_615.png', 'Yes', 'Yes'),
(15, 'Ea alias error et no', 'Food_Category_593.png', 'No', 'No'),
(16, 'Pizza', '', 'Yes', 'No'),
(17, 'Burger', 'Food_Category_700.jpg', 'No', 'Yes'),
(18, 'Submarine', 'Food_Category_748.jpg', 'No', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_food`
--

CREATE TABLE `tbl_food` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(150) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `featured` varchar(10) NOT NULL,
  `active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_food`
--

INSERT INTO `tbl_food` (`id`, `title`, `description`, `price`, `image_name`, `category_id`, `featured`, `active`) VALUES
(18, 'Deleniti tempore vo', 'Labore sequi cupidit', '431.00', '', 13, 'Yes', 'Yes'),
(19, 'Ullam anim culpa tem', 'Ducimus aperiam vol', '758.00', 'Food_Category_3660.png', 13, 'No', 'Yes'),
(20, 'Qui magni possimus ', 'Dolores officia repu', '180.00', 'Food_Category_7644.jpg', 14, 'Yes', 'Yes'),
(21, 'Sit officia ducimus', 'Nemo sed fugiat ea ', '124.00', 'Food_Category_9032.jfif', 18, 'No', 'No'),
(22, 'Chicken Burget', 'This is chicken burger. Special Today', '1200.00', 'Food_Category_5918.png', 17, 'No', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `id` int(10) UNSIGNED NOT NULL,
  `food` varchar(150) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `order_date` datetime NOT NULL,
  `status` varchar(50) NOT NULL,
  `customer_name` varchar(150) NOT NULL,
  `customer_contact` int(10) NOT NULL,
  `customer_email` varchar(150) NOT NULL,
  `customer_address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`id`, `food`, `price`, `quantity`, `total`, `order_date`, `status`, `customer_name`, `customer_contact`, `customer_email`, `customer_address`) VALUES
(1, 'Qui magni possimus ', '180.00', 2, '360.00', '2022-05-18 11:08:38', 'Cancelled', 'Madonna Hobbs', 1234567890, 'kakaq@mailinator.com', 'Voluptates est minu'),
(2, 'Chicken Burger', '1200.00', 5, '6000.00', '2022-05-18 11:09:51', 'On Delivery', 'John', 754321891, 'John@gmail.com', 'Colombo, Maradhana'),
(3, 'Ullam anim culpa tem', '758.00', 3, '2274.00', '2022-05-18 11:16:03', 'Ordered', 'Graiden Ferrell', 987651234, 'xebuxilema@mailinator.com', 'Quo aliqua Ab est '),
(4, 'Deleniti tempore vo', '431.00', 2, '862.00', '2022-05-18 11:17:57', 'Delivered', 'Ashik', 777712345, 'Ashik@example.com', 'Kandy, Gampola'),
(5, 'Deleniti tempore vo', '431.00', 5, '2155.00', '2022-05-18 12:18:46', 'On Delivery', 'Mohamed', 765490870, 'Mohamed@example.com', 'Mawanella, Kegelle'),
(6, 'Qui magni possimus ', '180.00', 20, '3600.00', '2022-05-18 02:47:17', 'On Delivery', 'Smith', 765432119, 'Smith@gmail.com', 'Colombo, Gall face');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_food`
--
ALTER TABLE `tbl_food`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tbl_food`
--
ALTER TABLE `tbl_food`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
